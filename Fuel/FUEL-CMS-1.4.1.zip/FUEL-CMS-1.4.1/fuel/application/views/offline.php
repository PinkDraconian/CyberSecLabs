<?php fuel_set_var('layout', ''); ?>
<h1>The site is currently offline.</h1>
<p>Please try again later.</p>